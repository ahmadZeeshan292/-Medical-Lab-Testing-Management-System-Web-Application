const express = require('express');
const router = express.Router();
const { loginTechnician } = require('../controllers/technicianController');

router.post('/login', loginTechnician);

module.exports = router;