const express = require('express');
const router = express.Router();
const { bookAppointment, get_tests } = require('../controllers/appointmentController');

router.post('/book', bookAppointment);
router.post('/getTest', get_tests);

module.exports = router;
