const express = require('express');
const router = express.Router();
const { submitReport, getPatientReports, getBookedAppointments, getTestParameters, getPatientReportDetails, getPatientAppointmentsSummary} = require('../controllers/reportController');

// Use the controller functions as route handlers
router.post('/submit', submitReport);
router.get('/patient/:id', getPatientReports);

// New routes for fetching booked appointments and test parameters
router.get('/booked-appointments', getBookedAppointments);
router.get('/test-parameters/:test_type', getTestParameters);
router.post('/get-summary', getPatientAppointmentsSummary);
router.post('/get-report', getPatientReportDetails);

module.exports = router;
