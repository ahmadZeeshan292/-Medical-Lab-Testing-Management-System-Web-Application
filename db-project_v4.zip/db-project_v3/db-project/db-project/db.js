const sql = require('mssql/msnodesqlv8');

const config = {
  connectionString: 'Driver={ODBC Driver 17 for SQL Server};Server=LAPTOP-PG0NHTGS\\SQLEXPRESS;Database=DB_Project;Trusted_Connection=Yes;'
};

const poolPromise = new sql.ConnectionPool(config)
  .connect()
  .then(async (pool) => {
    console.log('✅ Connected to SQL Server');
    return pool; // Return the pool for future use
  })
  .catch(err => {
    console.error('❌ Database connection failed:', err);
  });

module.exports = {
  poolPromise,
  sql
};
