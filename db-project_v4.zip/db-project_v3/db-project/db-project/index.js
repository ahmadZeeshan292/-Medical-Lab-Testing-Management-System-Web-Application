require('dotenv').config();
const express = require('express');
const path = require('path');
const { poolPromise } = require('./db'); // Ensure this file exports poolPromise properly

const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files (HTML, CSS, JS, etc.) from /public folder
app.use(express.static(path.join(__dirname, 'public','Diagnostic_updated', 'Medilab', 'Medilab')));

// Import route modules
const patientRoutes     = require('./routes/patient');
const appointmentRoutes = require('./routes/appointment');
const technicianRoutes  = require('./routes/technician');
const reportRoutes      = require('./routes/report');

// Mount API routes
app.use('/patients',     patientRoutes);
app.use('/appointments', appointmentRoutes);
app.use('/technicians',  technicianRoutes);
app.use('/reports',      reportRoutes);

// Default route — serve signup.html at root URL
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public','Diagnostic_updated', 'Medilab', 'Medilab', 'login.html'));
});

// Optional route to test DB connection
app.get('/test-db', async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request().query('SELECT TOP 10 * FROM Patients1');
    res.json(result.recordset);
  } catch (err) {
    console.error('❌ Database test error:', err);
    res.status(500).send('Database connection failed');
  }
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
